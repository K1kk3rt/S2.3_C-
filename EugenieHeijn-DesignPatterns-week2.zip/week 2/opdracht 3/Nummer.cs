﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opdracht_3
{
    public class Nummer
    {
        public string artiest;
        public string nummer;

        //construct
        public Nummer(string artiest, string nummer)
        {
            this.artiest = artiest;
            this.nummer = nummer;
        }
    }
}
